for i in range(0,7):
    print((7-i)*" ",(i+1)*"* ", (7-i)*" ")