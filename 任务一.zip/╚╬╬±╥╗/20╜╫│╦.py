n=0
sum=1
k=1
m = 1
while k<=20:
      while m<=k:
            sum=sum*m
            m=m+1
      k=k+1
      n=n+sum
print(n)