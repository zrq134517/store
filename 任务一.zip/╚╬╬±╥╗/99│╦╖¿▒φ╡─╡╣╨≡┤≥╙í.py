n = 10
while n>0:
      n = n - 1
      m = 1
      while  m<n+1:
             print(m,"*",n,"=",m*n,end="  ")
             m = m + 1
      print()