import random #import 引入模块、包。
#while True:
ran=random.randint(50,150)
print(ran)
