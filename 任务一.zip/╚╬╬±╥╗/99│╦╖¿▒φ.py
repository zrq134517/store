n=0
while n<9:
      n = n + 1
      m = 1
      while  m<=n:
             print(m,"*",n,"=",m * n,end="  ")
             m = m + 1
      print()




