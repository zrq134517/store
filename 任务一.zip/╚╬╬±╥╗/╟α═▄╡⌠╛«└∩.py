h = 20
r = 0
while h > 0:
    h = h - 3
    if h<=0:
       r = r + 1
       break
    else:
        h=h+2
        r = r + 1
print(r)
