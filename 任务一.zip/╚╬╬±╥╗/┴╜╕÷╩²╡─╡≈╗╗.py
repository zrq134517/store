a=int(input())
b=int(input())
a=a+b
b=a-b
a=a-b
print("A=",a,"B=",b)


