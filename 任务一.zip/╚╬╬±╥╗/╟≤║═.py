n=0
m=0
while m<10:
     num=int(input())
     m=m+1
     n=n+num
print("和=",n)